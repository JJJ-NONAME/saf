"""
© 2025 ANSYS, Inc.  Unauthorized use, distribution, or duplication is prohibited.
"""

if __name__ == "__main__":
    print("This is a custom test package for installer testing.")
